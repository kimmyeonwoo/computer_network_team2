"""Tests for the real local SMTP server and the report client."""
import threading
import unittest
from unittest import mock

from analyzer import Analyzer
import smtp_client
from traffic import TCPServer, SMTPHandler
from verify import frame


class SMTPIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.server = TCPServer(('127.0.0.1', 0), SMTPHandler)
        self.thread = threading.Thread(target=self.server.serve_forever,
                                       kwargs={'poll_interval': 0.02}, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)

    def test_real_mail_transaction(self):
        result = smtp_client.run_experiment('127.0.0.1', self.server.server_address[1],
                                            source_ip='127.0.0.1', source_port=0)
        self.assertTrue(result['success'], result)
        self.assertTrue(result['mail_accepted'])
        self.assertEqual([x['code'] for x in result['transcript']], [220, 250, 250, 250, 250, 221])
        self.assertEqual([x['step'] for x in result['transcript']],
                         ['서버 연결', 'EHLO', 'MAIL FROM', 'RCPT TO', 'DATA / 본문 전송', 'QUIT'])
        self.assertTrue(result['client'].startswith('127.0.0.1:'))

    def test_probe_does_not_send_mail(self):
        result = smtp_client.run_experiment('127.0.0.1', self.server.server_address[1],
                                            'probe', '127.0.0.1', 0)
        self.assertTrue(result['success'], result)
        self.assertFalse(result['mail_accepted'])
        self.assertEqual([x['step'] for x in result['transcript']], ['서버 연결', 'EHLO', 'NOOP', 'QUIT'])


class SMTPConfigurationTests(unittest.TestCase):
    def test_report_client_source_address(self):
        with mock.patch('smtp_client.LabSMTP') as factory:
            client = factory.return_value
            client.connect.return_value = (220, b'ready')
            client.sock.getsockname.return_value = ('172.30.0.20', 57460)
            for name in ('ehlo', 'mail', 'rcpt', 'data'):
                getattr(client, name).return_value = (250, b'OK')
            client.quit.return_value = (221, b'Bye')
            result = smtp_client.run_experiment()
            factory.assert_called_once_with(timeout=8, local_hostname='packet-lab.invalid',
                                             source_address=('172.30.0.20', 57460))
            client.connect.assert_called_once_with('172.30.0.10', 25)
            self.assertTrue(result['success'])
            client.login.assert_not_called()

    def test_failure_is_not_retried(self):
        with mock.patch('smtp_client.LabSMTP') as factory:
            client = factory.return_value
            client.connect.return_value = (220, b'ready')
            client.sock.getsockname.return_value = ('172.30.0.20', 57460)
            client.ehlo.return_value = (250, b'OK')
            client.mail.return_value = (451, b'temporary failure')
            result = smtp_client.run_experiment()
            self.assertFalse(result['success'])
            self.assertEqual(result['failed_step'], 'MAIL FROM')
            client.mail.assert_called_once()
            client.data.assert_not_called()

    def test_loopback_has_one_copy_with_client_directions(self):
        import capture
        from smtp_client import CLIENT_HOST
        with mock.patch('capture.require_ubuntu'), mock.patch.object(capture.socket, 'AF_PACKET', 17, create=True), mock.patch('capture.socket.socket') as factory:
            backend = capture.LinuxCapture('lo')
            payload = frame(b'EHLO packet-lab.invalid\r\n', src='172.30.0.20', dst='172.30.0.10', sport=57460, dport=25)
            factory.return_value.recvfrom.side_effect = [(payload, ('lo', 0x800, 4, 772, b'')), (payload, ('lo', 0x800, 0, 772, b''))]
            self.assertEqual(backend.read(), [])
            stamp, actual, direction = backend.read()[0]
            p = Analyzer().decode(actual, 1, stamp, direction, CLIENT_HOST)
            self.assertEqual(p['direction'], '송신')
            self.assertEqual(p['messages'][0]['smtp'], 'EHLO packet-lab.invalid')


class ApplicationRoutingTests(unittest.TestCase):
    def test_gui_smtp_sends_to_own_server_on_loopback(self):
        import app
        from types import SimpleNamespace
        state = app.LabState()
        state.running, state.interface = True, 'lo'
        def immediate_thread(*args, **kwargs):
            return SimpleNamespace(start=kwargs['target'])
        with mock.patch('app.threading.Thread', side_effect=immediate_thread), mock.patch('app.smtp_lab_experiment', return_value={'success': True}) as send:
            state.run_tests({'protocol': 'SMTP', 'mode': 'lab-send'})
            send.assert_called_once_with('172.30.0.10', 25, 'lab-send')
            self.assertFalse(state.test_running)
            self.assertTrue(state.test_result)


class AddressSetupTests(unittest.TestCase):
    def test_up_adds_only_missing_loopback_addresses(self):
        import lab_setup
        existing = '[{"ifname":"lo","addr_info":[{"local":"172.30.0.10"}]}]'
        with mock.patch('lab_setup.STATE') as state, mock.patch('lab_setup.ip', return_value=existing) as ip:
            state.exists.return_value = False
            lab_setup.setup()
            ip.assert_any_call('address', 'add', '172.30.0.20/32', 'dev', 'lo')
            self.assertEqual(ip.call_count, 2)
            state.write_text.assert_called_once_with('["172.30.0.20"]')

    def test_up_does_not_change_existing_physical_network(self):
        import lab_setup
        existing = '[{"ifname":"enp0s8","addr_info":[{"local":"172.30.0.10"}]}]'
        with mock.patch('lab_setup.ip', return_value=existing) as ip:
            with self.assertRaises(RuntimeError):
                lab_setup.setup()
            self.assertEqual(ip.call_count, 1)

    def test_down_removes_only_owned_address(self):
        import lab_setup
        existing = '[{"ifname":"lo","addr_info":[{"local":"172.30.0.10"},{"local":"172.30.0.20"}]}]'
        with mock.patch('lab_setup.STATE') as state, mock.patch('lab_setup.ip', return_value=existing) as ip:
            state.exists.return_value = True
            state.read_text.return_value = '["172.30.0.20"]'
            lab_setup.cleanup()
            ip.assert_any_call('address', 'del', '172.30.0.20/32', 'dev', 'lo')
            self.assertEqual(ip.call_count, 2)
            state.unlink.assert_called_once()


if __name__ == '__main__':
    unittest.main()
