"""Optional single-VM setup: add only two temporary /32 addresses to lo."""
import argparse
import json
import os
from pathlib import Path
import subprocess
from runtime import require_ubuntu

ADDRESSES = ('172.30.0.10', '172.30.0.20')
STATE = Path('/run/packet-lab-addresses.json')


def ip(*args):
    return subprocess.run(['ip', *args], check=True, text=True, capture_output=True).stdout


def setup():
    existing = json.loads(ip('-j', '-4', 'address', 'show'))
    locations = {address['local']: interface['ifname'] for interface in existing
                 for address in interface.get('addr_info', [])}
    for address in ADDRESSES:
        if address in locations and locations[address] != 'lo':
            raise RuntimeError('{}가 이미 {}에 있습니다. 기존 테스트망을 사용하세요.'.format(address, locations[address]))
    owned = json.loads(STATE.read_text()) if STATE.exists() else []
    if not isinstance(owned, list) or any(x not in ADDRESSES for x in owned):
        raise RuntimeError('실험 주소 상태 파일 형식을 확인하세요.')
    added = []
    try:
        for address in ADDRESSES:
            if address not in locations:
                ip('address', 'add', address + '/32', 'dev', 'lo')
                added.append(address)
        STATE.write_text(json.dumps(sorted(set(owned + added))))
    except Exception:
        for address in added:
            ip('address', 'del', address + '/32', 'dev', 'lo')
        raise
    print('SMTP 테스트 주소 준비 완료. 서버 172.30.0.10:25 / 클라이언트 172.30.0.20:57460')
    print('이 한 VM 구성에서는 프로그램과 Wireshark 모두 lo를 선택하세요.')
    print('HTTP·DNS 외부 실험은 인터넷 인터페이스에서 별도로 캡처하세요.')


def cleanup():
    if not STATE.exists():
        print('이 도구가 추가한 주소가 없습니다.')
        return
    owned = json.loads(STATE.read_text())
    if not isinstance(owned, list) or any(x not in ADDRESSES for x in owned):
        raise RuntimeError('실험 주소 상태 파일 형식을 확인하세요.')
    existing = json.loads(ip('-j', '-4', 'address', 'show', 'dev', 'lo'))
    active = {a['local'] for interface in existing for a in interface.get('addr_info', [])}
    for address in owned:
        if address in active:
            ip('address', 'del', address + '/32', 'dev', 'lo')
    STATE.unlink()
    print('이 도구가 추가한 테스트 주소만 제거했습니다.')


def main():
    parser = argparse.ArgumentParser(description='한 우분투 VM에서 SMTP 실험 주소 준비·정리')
    parser.add_argument('action', choices=['up', 'down'])
    args = parser.parse_args()
    try:
        require_ubuntu()
        if os.geteuid() != 0:
            raise RuntimeError('sudo python3 lab_setup.py {}로 실행하세요.'.format(args.action))
        setup() if args.action == 'up' else cleanup()
    except (OSError, ValueError, RuntimeError, subprocess.CalledProcessError) as exc:
        parser.exit(1, '주소 설정 실패: {}\n'.format(exc))


if __name__ == '__main__':
    main()
