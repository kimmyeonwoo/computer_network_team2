# Ubuntu Raw Socket 패킷 분석 — 보고서 SMTP 구성 반영

캡처 프로그램은 Ubuntu Linux 전용입니다. 패킷은 AF_PACKET·SOCK_RAW로 수집합니다. HTTP·DNS는 외부 서버, SMTP는 직접 실행한 테스트 서버를 사용합니다. Python 3 표준 라이브러리만 사용합니다.

## 바뀐 부분

- `traffic.py` 실행 시 SMTP 서버가 기본 `172.30.0.10:25`에서 대기합니다.
- `smtp_client.py`를 추가했습니다. 기본 출발지는 `172.30.0.20:57460`입니다.
- EHLO → MAIL FROM → RCPT TO → DATA·본문 → QUIT을 실제로 주고받습니다.
- GUI의 SMTP 기본값과 메일 전송 버튼도 자체 테스트 서버로 연결합니다.
- 서버가 접수한 테스트 메일은 외부 메일함으로 전달하지 않습니다.
- 캡처한 원본 바이트만 분석·PCAP 저장합니다. Seq/Ack, TTL, 패킷 번호·길이·개수를 생성하거나 기존 사진의 숫자로 맞추지 않습니다. 실행마다 TCP 번호와 패킷 분할·ACK 결합·개수는 달라질 수 있습니다.

## 1. 프로그램 실행

ZIP을 우분투 안에서 풀고 `app.py`가 있는 폴더에서 터미널을 엽니다.

```bash
sudo python3 app.py --no-browser
```

우분투 브라우저: `http://127.0.0.1:8765/`

기존 앱은 먼저 해당 터미널의 Ctrl+C로 종료합니다.

## 2. HTTP·DNS (기존 방식)

인터넷 인터페이스(예: `enp0s8`)에서 캡처를 시작합니다. 이름은 `ip route get 1.1.1.1` 결과의 `dev` 뒤에서 확인할 수 있습니다. 요청은 새 터미널에서 보냅니다.

```bash
curl -4 -v --http1.1 http://example.com/
dig @1.1.1.1 example.com A
dig @1.1.1.1 example.com AAAA
dig @1.1.1.1 example.com MX
```

## 3. 직접 실행한 SMTP 서버로 실험

### 이미 테스트망이 준비된 경우

서버 쪽 Ubuntu에 `172.30.0.10`, 클라이언트 쪽 Ubuntu에 `172.30.0.20`이 실제로 할당돼 있어야 합니다. 주소만 소스에 적는 것으로 네트워크가 만들어지지는 않습니다.

서버 쪽에서:

```bash
sudo python3 traffic.py
```

클라이언트 쪽에서 캡처 프로그램·Wireshark를 해당 네트워크 인터페이스로 시작한 뒤:

```bash
python3 smtp_client.py 172.30.0.10 25
```

GUI의 SMTP 연결 확인·테스트 메일 보내기도 같은 서버를 사용합니다. 서버는 GUI가 자동으로 시작하지 않으므로 별도 터미널에서 실행해 둡니다.

### 우분투 가상 머신 한 대에서 빠르게 확인하기

별도 테스트망이 없다면 아래 보조 도구로 `lo`에 두 개의 임시 /32 주소를 추가할 수 있습니다. 기존 인터넷 인터페이스·DNS·기본 경로는 변경하지 않습니다. 두 주소가 이미 다른 인터페이스에 있으면 중단합니다.

터미널 1 — 주소를 준비하고 서버를 실행:

```bash
sudo python3 lab_setup.py up
sudo python3 traffic.py
```

터미널 2 — 프로그램 실행:

```bash
sudo python3 app.py --no-browser
```

브라우저에서 **`lo`를 선택하고 캡처 시작**을 누릅니다. Wireshark에서도 `lo`를 선택합니다. 이 한 VM 방식의 실제 인터페이스는 `enp0s8`이 아닌 `lo`입니다. SMTP 송수신 방향은 `172.30.0.20` 클라이언트 관점으로 표시하고, Linux loopback의 중복 송신 사본은 저장하지 않습니다. 분석 결과와 패킷 수는 원본 캡처를 기준으로 하며 기존 PPT 사진과 동일한 수치·개수를 보장하지 않습니다.

터미널 3 — 보고서에 적힌 클라이언트 명령:

```bash
python3 smtp_client.py 172.30.0.10 25
```

종료 후 프로그램·서버를 Ctrl+C로 끄고 추가한 주소만 정리합니다.

```bash
sudo python3 lab_setup.py down
```

단일 VM 방식은 실험 편의를 위한 별도 구성입니다. 보고서의 기존 캡처 환경 자체를 재현했다고 단정하는 방식은 아닙니다.

### 다른 테스트 주소·포트

서버:

```bash
sudo python3 traffic.py --host 127.0.0.1 --port 2525
```

클라이언트:

```bash
python3 smtp_client.py 127.0.0.1 2525 --source-ip 127.0.0.1 --source-port 0
```

원래 출발지 포트가 아직 사용 중이면 `--source-port 0`으로 임시 포트를 지정할 수 있습니다. 이 경우 실제 클라이언트 포트는 결과와 캡처에서 확인합니다. 127.0.0.1 단일 주소의 송수신 표시는 기존 보고서의 두 IP 방식과 다릅니다.

## 4. Wireshark 비교

앱과 Wireshark에서 같은 인터페이스로 캡처를 먼저 시작하고, 요청을 한 번 실행한 뒤 둘 다 중지합니다.

| 대상 | 표시 필터 |
|---|---|
| HTTP | `tcp.port == 80` |
| DNS | `udp.port == 53 && ip.addr == 1.1.1.1` |
| 기본 SMTP 서버 | `tcp.port == 25 && ip.addr == 172.30.0.10` |

IP·포트·방향과 TCP의 원시 Seq/Ack, DNS Transaction ID로 같은 패킷을 찾습니다. 두 도구의 패킷 번호는 다를 수 있습니다. 프로그램이 저장한 PCAP을 Wireshark로 열어 해석 결과를 비교할 수도 있습니다.

## 5. 파일별 역할

| 파일 | 역할 |
|---|---|
| app.py | GUI 서버, 캡처 제어, PCAP 저장 |
| capture.py | Ubuntu AF_PACKET·SOCK_RAW 캡처 |
| analyzer.py | IP·TCP/UDP·HTTP·DNS·SMTP 분석 |
| external.py | 외부 HTTP·DNS 실험 및 SMTP 클라이언트 실행 진입점 |
| traffic.py | 기본 172.30.0.10:25 SMTP 서버 (기존 로컬 보조 클래스도 유지) |
| smtp_client.py | 자체 SMTP 서버에 실제 테스트 메일 전송 |
| lab_setup.py | 단일 VM 시험용 임시 주소 추가·정리 |
| runtime.py | Ubuntu 실행 환경 확인 |
| ui.html | 패킷 목록·상세·실험 화면 |

```bash
python3 -m unittest verify test_capture test_smtp_lab
```

위 검사에는 로컬 127.0.0.1 임시 포트에서 실제 SMTP 명령·응답을 주고받는 검사가 포함됩니다. Ubuntu의 25번 포트·임시 주소 설정 및 Raw Socket 실캡처는 실제 우분투에서 별도로 확인해야 합니다.
