"""Client for the team's own SMTP test server. No real mail relay is used."""
import argparse
import ipaddress
import json
import smtplib
import socket

from runtime import require_ubuntu

SMTP_HOST = '172.30.0.10'
SMTP_PORT = 25
CLIENT_HOST = '172.30.0.20'
CLIENT_PORT = 57460
BODY = ('From: sender@example.test\r\nTo: receiver@example.test\r\n'
        'Subject: Packet Lab SMTP test\r\n\r\nSMTP packet capture test.\r\n')


class LabSMTP(smtplib.SMTP):
    def _get_socket(self, host, port, timeout):
        # Reuse the selected source port after a previous test closes.
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            sock.settimeout(timeout)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            if self.source_address:
                sock.bind(self.source_address)
            sock.connect((host, port))
            return sock
        except Exception:
            sock.close()
            raise


def run_experiment(host=SMTP_HOST, port=SMTP_PORT, mode='lab-send',
                   source_ip=None, source_port=None):
    if host == 'localhost':
        host = '127.0.0.1'
    try:
        address = ipaddress.IPv4Address(host)
    except ipaddress.AddressValueError as exc:
        raise ValueError('직접 실행한 테스트 서버의 IPv4 주소를 입력하세요.') from exc
    if not address.is_private or address.is_multicast or address.is_unspecified:
        raise ValueError('이 클라이언트는 사설망 또는 로컬 테스트 서버용입니다.')
    if mode not in ('probe', 'lab-send'):
        raise ValueError('SMTP 모드는 probe 또는 lab-send입니다.')
    port = int(port)
    if not 1 <= port <= 65535:
        raise ValueError('서버 포트 범위는 1~65535입니다.')
    if source_ip is None:
        source_ip = CLIENT_HOST if host == SMTP_HOST else '0.0.0.0'
    if source_port is None:
        source_port = CLIENT_PORT if host == SMTP_HOST else 0
    source = (str(ipaddress.IPv4Address(source_ip)), int(source_port))
    if not 0 <= source[1] <= 65535:
        raise ValueError('클라이언트 포트 범위는 0~65535입니다.')
    result = {'protocol': 'SMTP', 'target': '{}:{}'.format(host, port),
              'mode': mode, 'transcript': [], 'mail_accepted': False,
              'note': '직접 실행한 테스트 서버와 통신합니다. 외부 메일함으로 전달하지 않습니다.'}
    client = LabSMTP(timeout=8, local_hostname='packet-lab.invalid', source_address=source)
    step = '서버 연결'

    def record(name, response, expected):
        code, reply = response
        result['transcript'].append({'step': name, 'code': code,
                                     'reply': reply.decode('utf-8', 'replace')})
        if code not in expected:
            raise smtplib.SMTPResponseException(code, reply)

    try:
        record(step, client.connect(host, port), (220,))
        local = client.sock.getsockname()
        result['client'] = '{}:{}'.format(local[0], local[1])
        step = 'EHLO'
        record(step, client.ehlo(), (250,))
        if mode == 'probe':
            step = 'NOOP'
            record(step, client.noop(), (250,))
        else:
            step = 'MAIL FROM'
            record(step, client.mail('sender@example.test'), (250,))
            step = 'RCPT TO'
            record(step, client.rcpt('receiver@example.test'), (250,))
            step = 'DATA / 본문 전송'
            record(step, client.data(BODY), (250,))
            result['mail_accepted'] = True
        step = 'QUIT'
        record(step, client.quit(), (221,))
        result['success'] = True
    except (OSError, smtplib.SMTPException) as exc:
        result.update(success=False, failed_step=step, error=str(exc))
        if isinstance(exc, smtplib.SMTPResponseException):
            result['smtp_code'] = exc.smtp_code
            result['server_reply'] = exc.smtp_error.decode('utf-8', 'replace')
        if isinstance(exc, OSError) and exc.errno == 99:
            result['error_hint'] = ('클라이언트 IP가 이 우분투에 없습니다. 실제 테스트망을 설정하거나 '
                                    '한 VM 시험은 sudo python3 lab_setup.py up으로 주소를 준비하세요.')
    finally:
        client.close()
    return result


def main():
    parser = argparse.ArgumentParser(description='직접 실행한 SMTP 서버에 테스트 메일 1통 전송')
    parser.add_argument('host', nargs='?', default=SMTP_HOST)
    parser.add_argument('port', nargs='?', type=int, default=SMTP_PORT)
    parser.add_argument('--source-ip')
    parser.add_argument('--source-port', type=int)
    parser.add_argument('--mode', choices=['probe', 'lab-send'], default='lab-send')
    args = parser.parse_args()
    try:
        require_ubuntu()
        result = run_experiment(args.host, args.port, args.mode, args.source_ip, args.source_port)
    except (ValueError, RuntimeError) as exc:
        parser.exit(1, '{}\n'.format(exc))
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if not result['success']:
        parser.exit(1)


if __name__ == '__main__':
    main()
